# SV002 M11 Disposition Gate Test Payload

This documentation-only payload exists to test the incoming disposition gate.

It should be uploaded as a ZIP file into:

```text
incoming/
```

Expected behavior:

```text
incoming/sv002_m11_disposition_gate_test_payload.zip
→ workflow selects the changed incoming payload
→ payload is hashed
→ payload is staged under tracking/incoming_mailbox/<sha>/
→ pipeline evaluates the staged copy
→ disposition record is written
→ payload is removed from incoming/
→ incoming/ returns to README.md only
```

This payload intentionally contains no workflow files, no executable code, no root README replacement, no secrets, and no authority expansion.
