# iOS No-Period Mirror

Canonical workflow path:

```text
.github/workflows/core-lite-intake.yml
```

iOS-safe mirror:

```text
iosnoperiod/github/workflows/core-lite-intake-yml
```

Mapping:

```text
iosnoperiod/github/workflows/core-lite-intake-yml
→ .github/workflows/core-lite-intake.yml
```

The mirror exists only to prevent iOS from stripping or hiding leading-dot paths.
