# Manual / Automated Ingestion Notes

This bundle corrects push activation.

## Trigger rule

Only this path activates `core-lite-intake` on push:

```text
incoming/**
```

## Usage

1. Install this bundle.
2. Commit it normally.
3. Future automated ingestion is done by pushing a bundle/file into:

```text
incoming/
```

For example:

```text
incoming/sv002_m11_triad_binding_resolver_ingestion_bundle.zip
```

That incoming push will run `declared-input-route(push:incoming)`.

## Canonical workflow path

```text
.github/workflows/core-lite-intake.yml
```

## iOS-safe mirror

```text
iosnoperiod/github/workflows/core-lite-intake-yml
```
