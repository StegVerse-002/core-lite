# StegVerse-002 Ingestion Smoke Test

Generated: `2026-05-26T01:58:14Z`

## Purpose

This is a harmless test bundle for the `StegVerse-002/core-lite` ingestion engine.

It verifies that the engine can:

```text
find an incoming zip
read bundle_manifest.json
validate target paths
verify file hashes
install allowed files
emit ingestion receipt
write ingestion event
write ingest report
```

## Expected Target Path

After successful non-dry-run ingestion, this file should exist in the repo at:

```text
docs/ingestion_smoke_test/INGESTION_SMOKE_TEST.md
```

## Safety

This bundle does not contain:

```text
README.md
.github/workflows/
bundle_manifest.json as an install target
absolute paths
parent traversal paths
incoming/ target paths
```
