# SV002 Diagnostic Task — LLM Health Check

## Purpose

This is a diagnostic health check task for the StegVerse-002 governed
ingestion system. It verifies that the LLM provider is reachable,
the API key is valid, and the response schema is correct.

## Non-Negotiable Rule

Return exactly one fenced JSON block. No commentary. No prose.
No alternate plans. No claims that a patch was applied.

## Task

Produce a minimal valid candidate patch for the following no-op:

Add a one-line comment `# diagnostic-ok` to the file
`diagnostics/results/current/install_proof.txt`.

## Required Response Format

Respond with exactly one fenced JSON block matching this schema:

```json
{
  "schema": "stegverse.candidate_patch.v1",
  "candidate_id": "sv002-diag-health-check-001",
  "provider": "YOUR_PROVIDER_NAME",
  "description": "Diagnostic health check — add comment to install_proof.txt",
  "transition_class": "candidate",
  "authority_ref": "SV002-DIAG/diagnostic-health-check",
  "policy_ref": "triad/default-deny/no-broad-authority",
  "files": [
    {
      "path": "diagnostics/results/current/install_proof.txt",
      "operation": "write",
      "content": "# diagnostic-ok\n"
    }
  ]
}
```

Replace `YOUR_PROVIDER_NAME` with your actual provider name
(`claude` or `openai`).

Return only the JSON block. Nothing else.
