# SV002 Diagnostics

Governed health check harness for the StegVerse-002 ingestion system.

## What This Tests

Every run exercises all governed ingestion paths and verifies both LLM
providers are functional, API keys are valid, and response schemas are correct.

| Test | What It Verifies |
|---|---|
| Claude API | Key valid, endpoint reachable, schema correct, provider field set |
| OpenAI API | Key valid, endpoint reachable, schema correct, provider field set |
| Candidate path (Claude) | Candidate classification, evidence plane contribution |
| Candidate path (OpenAI) | Candidate classification, evidence plane contribution |
| Install path | Scoped write to diagnostics/results/current/ only |
| Repair path | Sandbox execution, boundary distance reduction |
| Fail-closed path | Deliberate quarantine, coherence collapse region marked |
| Evidence path | Evidence-only classification |

## Results

```
diagnostics/results/
  current/          ← this run
    run_summary.md      human-readable overall status
    claude_test.md      Claude API health details
    chatgpt_test.md     OpenAI API health details
    merged.md           combined receipt + path test summary
    candidate_validation.json
    path_test_report.json
    evidence_plane_summary.json
    install_proof.txt   written by install path test
  previous/         ← last run (rolled over before each run)
    (same structure)
  run_count.json    total runs to date
```

## Running

### Manual (workflow dispatch)

Trigger `core-lite-intake` with:
- `task_id: sv002.diagnostics.run`
- `agent_provider: none`

### Scheduled

Runs nightly via the `schedule` trigger in `.github/workflows/core-lite-intake.yml`.

### Local

```bash
ANTHROPIC_API_KEY=your_key OPENAI_API_KEY=your_key \
  python3 scripts/run_diagnostics.py --diag-dir diagnostics
```

## Receipt Chain

Every diagnostic run writes to:
- `receipts/current/diagnostic_receipt.jsonl` — org state transition record
- `diagnostics/results/current/` — human-readable outputs

The diagnostic receipt chain is part of the org state. Every run is
anchored in the evidence plane and contributes to the geometry of A.

## Failure Interpretation

| Symptom | Likely cause |
|---|---|
| `claude_ok: false, api_reachable: false` | ANTHROPIC_API_KEY expired or wrong |
| `claude_ok: false, schema_valid: false` | Claude returned prose instead of JSON |
| `paths_passed < paths_total` | Ingestion module not installed or broken |
| `ep_contributions: 0` | batch_ingestion module not installed |
| `fail_closed path not quarantined` | Transition Table gate not enforcing |
