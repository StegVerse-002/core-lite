# Workflow patch — add nightly diagnostic schedule
#
# Add this to the "on:" block in .github/workflows/core-lite-intake.yml
# after the existing push: trigger:
#
#   schedule:
#     - cron: '0 4 * * *'   # 04:00 UTC nightly
#
# Then add this to the workflow-summary job's run: script,
# in the TASK_ID/ROUTE resolution section:
#
#   if [ "${EVENT}" = "schedule" ]; then
#     TASK_ID="sv002.diagnostics.run"
#     ROUTE="declared-task-route(scheduled:diagnostics)"
#     EXPECTED="Run nightly diagnostic health check."
#   fi
#
# And add to declared-task-route job's if: condition:
#
#   if: ${{ github.event_name == 'schedule' || (github.event_name == 'workflow_dispatch' && ...) }}
#
# Full patched sections shown below for copy/paste reference.
#
# ---------------------------------------------------------------------------
# PATCH 1: Add to "on:" block (after push: block)
# ---------------------------------------------------------------------------
#
#   schedule:
#     - cron: '0 4 * * *'
#
# ---------------------------------------------------------------------------
# PATCH 2: Add to workflow-summary run: script (before ROUTE= assignment)
# ---------------------------------------------------------------------------
#
#   if [ "${EVENT}" = "schedule" ]; then
#     TASK_ID="sv002.diagnostics.run"
#   fi
#
# ---------------------------------------------------------------------------
# PATCH 3: Add schedule to declared-task-route if: condition
# ---------------------------------------------------------------------------
#
# Change:
#   if: ${{ github.event_name == 'workflow_dispatch' && inputs.agent_provider == 'none' && inputs.task_id != '' && inputs.input_type == '' && inputs.input_path == '' }}
#
# To:
#   if: ${{ (github.event_name == 'schedule') || (github.event_name == 'workflow_dispatch' && inputs.agent_provider == 'none' && inputs.task_id != '' && inputs.input_type == '' && inputs.input_path == '') }}
#
# ---------------------------------------------------------------------------
# PATCH 4: Set TASK_ID for schedule in declared-task-route Execute step
# ---------------------------------------------------------------------------
#
# Add before the python3 -m tools.scripts.task_dispatcher call:
#
#   if [ "${EVENT}" = "schedule" ]; then
#     TASK_ID_ARG="sv002.diagnostics.run"
#   else
#     TASK_ID_ARG="${{ inputs.task_id }}"
#   fi
#
# Then use ${TASK_ID_ARG} instead of "${{ inputs.task_id }}" in the call.
