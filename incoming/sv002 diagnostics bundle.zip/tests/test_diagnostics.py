#!/usr/bin/env python3
"""
tests/test_diagnostics.py — StegVerse-002
Tests for the diagnostic runner (no live API calls).
"""
import datetime, json, os, sys, tempfile, zipfile
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from scripts.run_diagnostics import (
    _extract_candidate, write_provider_md, write_merged_md,
    write_run_summary_md, _diag_manifest, _path_test_pass,
)


def now_utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def run_tests():
    results = []

    def record(name, passed, detail=""):
        results.append({"test": name, "passed": passed, "detail": detail})

    # _extract_candidate — valid
    valid_text = '''```json
{
  "schema": "stegverse.candidate_patch.v1",
  "candidate_id": "diag-001",
  "provider": "claude",
  "description": "test",
  "transition_class": "candidate",
  "authority_ref": "SV002-DIAG/test",
  "policy_ref": "triad/default-deny/no-broad-authority",
  "files": [{"path": "test.txt", "operation": "write", "content": "ok"}]
}
```'''
    candidate, error = _extract_candidate(valid_text, "claude")
    record("extract_valid_candidate", candidate is not None and error is None,
           f"candidate_id={candidate.get('candidate_id') if candidate else None}")

    # _extract_candidate — no JSON block
    _, error2 = _extract_candidate("just prose here", "claude")
    record("extract_no_json_block", error2 is not None, f"error={error2}")

    # _extract_candidate — multiple blocks
    two_blocks = valid_text + "\n" + valid_text
    _, error3 = _extract_candidate(two_blocks, "claude")
    record("extract_multiple_blocks", error3 is not None, f"error={error3}")

    # _extract_candidate — wrong schema
    wrong_schema = valid_text.replace(
        "stegverse.candidate_patch.v1", "wrong.schema"
    )
    _, error4 = _extract_candidate(wrong_schema, "claude")
    record("extract_wrong_schema", error4 is not None, f"error={error4}")

    # diag_manifest — candidate
    m = _diag_manifest("candidate", "claude")
    record("diag_manifest_candidate",
           m["transition"]["transition_class"] == "candidate" and
           m["transition"]["authority_class"] == "candidate_evidence_only",
           f"class={m['transition']['transition_class']}")

    # diag_manifest — malformed
    m_bad = _diag_manifest("candidate", malformed=True)
    record("diag_manifest_malformed",
           m_bad["transition"]["transition_class"] == "unknown_forbidden",
           f"class={m_bad['transition']['transition_class']}")

    # _path_test_pass
    record("path_test_pass_candidate",
           _path_test_pass("candidate_claude",
               {"final_disposition": "CANDIDATE_ACCEPTED"}),
           "candidate disposition")
    record("path_test_pass_fail_closed",
           _path_test_pass("fail_closed",
               {"final_disposition": "QUARANTINED_FAIL_CLOSED"}),
           "quarantine disposition")
    record("path_test_fail_unknown",
           not _path_test_pass("candidate_claude",
               {"final_disposition": ""}),
           "empty disposition fails")

    with tempfile.TemporaryDirectory() as tmpdir:
        # write_provider_md
        claude_result = {
            "provider": "claude",
            "timestamp_utc": now_utc(),
            "api_key_present": True,
            "api_reachable": True,
            "response_received": True,
            "schema_valid": True,
            "provider_field_correct": True,
            "candidate_id_present": True,
            "files_present": True,
            "round_trip_ms": 250,
            "error": "",
            "raw_response": "",
            "candidate": {"schema": "stegverse.candidate_patch.v1",
                          "candidate_id": "diag-001", "provider": "claude",
                          "files": [{"path": "t.txt"}]},
        }
        openai_result = {**claude_result, "provider": "openai",
                         "round_trip_ms": 300}

        claude_md = os.path.join(tmpdir, "claude_test.md")
        write_provider_md(claude_result, claude_md)
        record("write_provider_md_creates_file",
               os.path.exists(claude_md), "claude_test.md")
        content = open(claude_md).read()
        record("write_provider_md_shows_pass",
               "PASS" in content, f"has PASS: {'PASS' in content}")
        record("write_provider_md_shows_roundtrip",
               "250ms" in content, f"has 250ms: {'250ms' in content}")

        # write_merged_md
        path_results = {
            "candidate_claude": {"disposition": "CANDIDATE_ADMITTED",
                                  "pass": True},
            "fail_closed": {"disposition": "QUARANTINED_FAIL_CLOSED",
                             "pass": True},
        }
        ep_summary = {"total_contributions": 5, "boundary_data_points": 2,
                      "geometry_observable": False,
                      "by_region": {"interior_admissible_region": 3,
                                    "coherence_collapse": 2}}
        merged_md = os.path.join(tmpdir, "merged.md")
        write_merged_md(claude_result, openai_result, path_results,
                        ep_summary, merged_md)
        record("write_merged_md_creates_file",
               os.path.exists(merged_md), "merged.md")
        merged_content = open(merged_md).read()
        record("write_merged_md_shows_overall_pass",
               "PASS" in merged_content,
               f"has PASS: {'PASS' in merged_content}")
        record("write_merged_md_shows_ep",
               "5" in merged_content, "ep total in merged")

        # write_run_summary_md
        summary_md = os.path.join(tmpdir, "run_summary.md")
        write_run_summary_md(claude_result, openai_result, path_results,
                             ep_summary, summary_md, run_number=42)
        record("write_run_summary_md_creates_file",
               os.path.exists(summary_md), "run_summary.md")
        summary_content = open(summary_md).read()
        record("write_run_summary_md_shows_run_number",
               "#42" in summary_content,
               f"has #42: {'#42' in summary_content}")

    passed = sum(1 for r in results if r["passed"])
    failed = sum(1 for r in results if not r["passed"])
    verdict = "PASS" if failed == 0 else "FAIL"

    print(f"Tests: {passed}/{len(results)} passed — {verdict}")
    for r in results:
        print(f"  [{'PASS' if r['passed'] else 'FAIL'}] {r['test']}: {r['detail']}")

    os.makedirs("reports/current", exist_ok=True)
    with open("reports/current/diagnostics_test_report.json", "w") as f:
        json.dump({"schema": "stegverse.test_report.v1",
                   "timestamp_utc": now_utc(),
                   "test_suite": "test_diagnostics",
                   "verdict": verdict, "passed": passed,
                   "failed": failed, "total": len(results),
                   "results": results}, f, indent=2)
    return verdict == "PASS"


if __name__ == "__main__":
    ok = run_tests()
    sys.exit(0 if ok else 1)
