#!/usr/bin/env python3
"""
scripts/run_diagnostics.py — StegVerse-002

Diagnostic health check runner. Exercises all governed ingestion paths
and verifies LLM providers are functional.

Tests:
  1. Claude API health check (live call, schema validation)
  2. OpenAI API health check (live call, schema validation)
  3. Candidate path (both providers)
  4. Synthesis / merge path
  5. Sandbox + repair path
  6. Install path (diagnostics/ only)
  7. Fail-closed path (deliberate malformed manifest)
  8. Evidence path
  9. Evidence plane measurements
  10. Receipt chain integrity

Outputs (to diagnostics/results/current/):
  run_summary.md
  claude_test.md
  chatgpt_test.md
  merged.md
  candidate_validation.json
  synthesis_report.json
  sandbox_report.json
  quarantine_receipt.jsonl
  evidence_plane.jsonl
  install_proof.txt

Previous run is rolled to diagnostics/results/previous/ before each run.
"""
import argparse
import datetime
import hashlib
import json
import os
import re
import shutil
import sys
import time
import zipfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


def now_utc() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha256_str(data: str) -> str:
    return "sha256:" + hashlib.sha256(data.encode()).hexdigest()


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return "sha256:" + h.hexdigest()


def append_jsonl(path: str, record: dict) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "a") as f:
        f.write(json.dumps(record, sort_keys=True) + "\n")


def write_json(path: str, data: dict) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


def write_text(path: str, text: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        f.write(text)


# ---------------------------------------------------------------------------
# LLM health checks
# ---------------------------------------------------------------------------

def check_claude(api_key: str, task_md: str, results_dir: str) -> dict:
    """Call Claude API and validate response."""
    import urllib.request
    import urllib.error

    result = {
        "provider": "claude",
        "timestamp_utc": now_utc(),
        "api_key_present": bool(api_key),
        "api_reachable": False,
        "response_received": False,
        "schema_valid": False,
        "provider_field_correct": False,
        "candidate_id_present": False,
        "files_present": False,
        "round_trip_ms": 0,
        "error": "",
        "raw_response": "",
        "candidate": None,
    }

    if not api_key:
        result["error"] = "ANTHROPIC_API_KEY not set"
        return result

    payload = json.dumps({
        "model": "claude-sonnet-4-20250514",
        "max_tokens": 1024,
        "messages": [{"role": "user", "content": task_md}],
    }).encode()

    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=payload,
        headers={
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
        method="POST",
    )

    start = time.time()
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            result["api_reachable"] = True
            result["response_received"] = True
            body = json.loads(resp.read().decode())
            result["round_trip_ms"] = int((time.time() - start) * 1000)

            # Extract text content
            text = ""
            for block in body.get("content", []):
                if block.get("type") == "text":
                    text += block.get("text", "")
            result["raw_response"] = text

            # Extract and validate JSON block
            candidate, error = _extract_candidate(text, "claude")
            if error:
                result["error"] = error
            else:
                result["schema_valid"] = True
                result["provider_field_correct"] = (
                    candidate.get("provider") == "claude"
                )
                result["candidate_id_present"] = bool(
                    candidate.get("candidate_id")
                )
                result["files_present"] = len(
                    candidate.get("files", [])
                ) > 0
                result["candidate"] = candidate

    except urllib.error.HTTPError as e:
        result["round_trip_ms"] = int((time.time() - start) * 1000)
        result["api_reachable"] = True
        body = e.read().decode()
        result["error"] = f"HTTP {e.code}: {body[:200]}"
    except Exception as e:
        result["round_trip_ms"] = int((time.time() - start) * 1000)
        result["error"] = str(e)

    return result


def check_openai(api_key: str, task_md: str, results_dir: str) -> dict:
    """Call OpenAI API and validate response."""
    import urllib.request
    import urllib.error

    result = {
        "provider": "openai",
        "timestamp_utc": now_utc(),
        "api_key_present": bool(api_key),
        "api_reachable": False,
        "response_received": False,
        "schema_valid": False,
        "provider_field_correct": False,
        "candidate_id_present": False,
        "files_present": False,
        "round_trip_ms": 0,
        "error": "",
        "raw_response": "",
        "candidate": None,
    }

    if not api_key:
        result["error"] = "OPENAI_API_KEY not set"
        return result

    payload = json.dumps({
        "model": "gpt-4o",
        "max_tokens": 1024,
        "messages": [{"role": "user", "content": task_md}],
    }).encode()

    req = urllib.request.Request(
        "https://api.openai.com/v1/chat/completions",
        data=payload,
        headers={
            "Authorization": f"Bearer {api_key}",
            "content-type": "application/json",
        },
        method="POST",
    )

    start = time.time()
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            result["api_reachable"] = True
            result["response_received"] = True
            body = json.loads(resp.read().decode())
            result["round_trip_ms"] = int((time.time() - start) * 1000)

            text = body.get("choices", [{}])[0].get("message", {}).get(
                "content", ""
            )
            result["raw_response"] = text

            candidate, error = _extract_candidate(text, "openai")
            if error:
                result["error"] = error
            else:
                result["schema_valid"] = True
                result["provider_field_correct"] = (
                    candidate.get("provider") == "openai"
                )
                result["candidate_id_present"] = bool(
                    candidate.get("candidate_id")
                )
                result["files_present"] = len(
                    candidate.get("files", [])
                ) > 0
                result["candidate"] = candidate

    except Exception as e:
        result["round_trip_ms"] = int((time.time() - start) * 1000)
        result["error"] = str(e)

    return result


def _extract_candidate(text: str, expected_provider: str):
    """Extract and validate fenced JSON block from LLM response."""
    matches = re.findall(r"```json\s*(.*?)\s*```", text, re.DOTALL)
    if not matches:
        return None, "no fenced JSON block in response"
    if len(matches) > 1:
        return None, f"{len(matches)} fenced JSON blocks found — expected exactly 1"
    try:
        data = json.loads(matches[0])
    except json.JSONDecodeError as e:
        return None, f"JSON parse error: {e}"
    if data.get("schema") != "stegverse.candidate_patch.v1":
        return None, f"wrong schema: {data.get('schema')}"
    return data, None


# ---------------------------------------------------------------------------
# Diagnostic bundle path tests
# ---------------------------------------------------------------------------

def make_diag_bundle(tmpdir: str, manifest: dict, name: str) -> str:
    path = os.path.join(tmpdir, name)
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("bundle_manifest.json", json.dumps(manifest, indent=2))
    return path


def _diag_manifest(transition_class: str, provider: str = "",
                   malformed: bool = False) -> dict:
    if malformed:
        return {"schema": "stegverse.bundle_manifest.v1",
                "transition": {"transition_class": "unknown_forbidden"}}
    base = {
        "schema": "stegverse.bundle_manifest.v1",
        "bundle_name": f"diag_{transition_class}",
        "transition": {
            "transition_class": transition_class,
            "transition_cell": f"SV002.DIAG.{transition_class.upper()}",
            "authority_class": (
                "candidate_evidence_only" if transition_class == "candidate"
                else "evidence_only" if transition_class == "evidence"
                else "scoped_repo_write"
            ),
            "state_effect": (
                "evidence_state" if transition_class in ("candidate", "evidence")
                else "code_state"
            ),
            "binding_level": (
                "non_binding" if transition_class in ("candidate", "evidence")
                else "commit_candidate"
            ),
            "task_ref": "diagnostics/diagnostic_task.md",
            "task_hash": sha256_str("sv002-diagnostic-task-v1"),
            "candidate_provider": provider,
            "candidate_round": 1,
            "allowed_paths": ["diagnostics/results/current/"],
            "forbidden_paths": ["secrets/", ".env"],
            "rollback_policy": "git_revert",
        },
        "files": [{
            "path": "diagnostics/results/current/install_proof.txt",
            "operation": "write",
            "content": f"# diagnostic-ok\n# path: {transition_class}\n# provider: {provider}\n# timestamp: {now_utc()}\n",
        }] if transition_class == "install" else [],
    }
    return base


def run_path_tests(results_dir: str, dry_run: bool = False) -> dict:
    """Run all diagnostic bundle path tests."""
    import tempfile

    path_results = {
        "candidate_claude": None,
        "candidate_openai": None,
        "install": None,
        "repair": None,
        "fail_closed": None,
        "evidence": None,
    }

    try:
        from core_lite.batch_ingestion import BatchIngestionController

        controller = BatchIngestionController(
            repo_root=".",
            mailbox_root="diagnostics/mailbox",
            tracking_root="tracking",
            report_dir=results_dir,
            receipt_dir=results_dir,
            quarantine_dir="diagnostics/quarantine",
            dist_dir="diagnostics/dist",
            sandbox_dist_dir="diagnostics/sandbox",
            entity="StegVerse-002",
            stage="SV002-DIAG",
            dry_run=True,  # Always dry_run for diagnostics
        )

        with tempfile.TemporaryDirectory() as tmpdir:
            bundles = {
                "candidate_claude": make_diag_bundle(
                    tmpdir,
                    _diag_manifest("candidate", "claude"),
                    "diag_candidate_claude.zip"
                ),
                "candidate_openai": make_diag_bundle(
                    tmpdir,
                    _diag_manifest("candidate", "openai"),
                    "diag_candidate_openai.zip"
                ),
                "install": make_diag_bundle(
                    tmpdir,
                    _diag_manifest("install"),
                    "diag_install.zip"
                ),
                "repair": make_diag_bundle(
                    tmpdir,
                    _diag_manifest("repair"),
                    "diag_repair.zip"
                ),
                "fail_closed": make_diag_bundle(
                    tmpdir,
                    _diag_manifest("candidate", malformed=True),
                    "diag_fail_closed.zip"
                ),
                "evidence": make_diag_bundle(
                    tmpdir,
                    _diag_manifest("evidence"),
                    "diag_evidence.zip"
                ),
            }

            for name, bundle_path in bundles.items():
                proc = controller.process_bundle(bundle_path)
                path_results[name] = {
                    "disposition": proc.get("final_disposition"),
                    "decision": proc.get("gate_result", {}).get("decision"),
                    "ep_contributions": len(
                        proc.get("evidence_plane_contributions", [])
                    ),
                    "pass": _path_test_pass(name, proc),
                }

    except ImportError as e:
        for k in path_results:
            path_results[k] = {
                "disposition": "SKIPPED",
                "error": f"batch_ingestion not installed: {e}",
                "pass": False,
            }

    return path_results


def _path_test_pass(name: str, proc: dict) -> bool:
    disposition = proc.get("final_disposition", "")
    if name in ("candidate_claude", "candidate_openai"):
        return "CANDIDATE" in disposition or "ADMITTED" in disposition
    elif name == "install":
        return "INSTALL" in disposition or "ADMITTED" in disposition
    elif name == "repair":
        return disposition not in ("", "UNKNOWN")
    elif name == "fail_closed":
        return "QUARANTINE" in disposition or "FAIL" in disposition
    elif name == "evidence":
        return "ADMITTED" in disposition or "CANDIDATE" in disposition
    return False


# ---------------------------------------------------------------------------
# Report writers
# ---------------------------------------------------------------------------

def write_provider_md(result: dict, path: str) -> None:
    provider = result["provider"].title()
    status = "PASS" if result["schema_valid"] else "FAIL"
    checks = [
        ("API key present", result["api_key_present"]),
        ("API reachable", result["api_reachable"]),
        ("Response received", result["response_received"]),
        ("Schema valid", result["schema_valid"]),
        ("Provider field correct", result["provider_field_correct"]),
        ("Candidate ID present", result["candidate_id_present"]),
        ("Files present", result["files_present"]),
    ]

    lines = [
        f"# {provider} Diagnostic Health Check",
        f"",
        f"**Status:** {status}",
        f"**Timestamp:** {result['timestamp_utc']}",
        f"**Round-trip:** {result['round_trip_ms']}ms",
        f"",
        f"## Checks",
        f"",
    ]
    for check, passed in checks:
        lines.append(f"- {'✓' if passed else '✗'} {check}")

    if result["error"]:
        lines += ["", f"## Error", "", f"```", result["error"], f"```"]

    if result.get("candidate"):
        c = result["candidate"]
        lines += [
            "", "## Candidate Produced", "",
            f"- schema: `{c.get('schema')}`",
            f"- candidate_id: `{c.get('candidate_id')}`",
            f"- provider: `{c.get('provider')}`",
            f"- files: {len(c.get('files', []))}",
        ]

    write_text(path, "\n".join(lines) + "\n")


def write_merged_md(
    claude_result: dict,
    openai_result: dict,
    path_results: dict,
    ep_summary: dict,
    path: str,
) -> None:
    claude_ok = claude_result.get("schema_valid", False)
    openai_ok = openai_result.get("schema_valid", False)
    paths_ok = sum(1 for v in path_results.values()
                   if v and v.get("pass")) if path_results else 0
    paths_total = len(path_results)

    overall = "PASS" if (claude_ok and openai_ok and paths_ok == paths_total) else (
        "PARTIAL" if (claude_ok or openai_ok or paths_ok > 0) else "FAIL"
    )

    lines = [
        "# SV002 Diagnostic Run — Merged Summary",
        "",
        f"**Overall status:** {overall}",
        f"**Timestamp:** {now_utc()}",
        "",
        "## LLM Health",
        "",
        f"| Provider | API Reachable | Schema Valid | Round-trip |",
        f"|---|---|---|---|",
        f"| Claude | {'✓' if claude_result.get('api_reachable') else '✗'} "
        f"| {'✓' if claude_ok else '✗'} "
        f"| {claude_result.get('round_trip_ms', 0)}ms |",
        f"| OpenAI | {'✓' if openai_result.get('api_reachable') else '✗'} "
        f"| {'✓' if openai_ok else '✗'} "
        f"| {openai_result.get('round_trip_ms', 0)}ms |",
        "",
        "## Path Tests",
        "",
        f"| Path | Disposition | Pass |",
        f"|---|---|---|",
    ]

    for name, result in (path_results or {}).items():
        if result:
            lines.append(
                f"| {name} | {result.get('disposition', 'UNKNOWN')} "
                f"| {'✓' if result.get('pass') else '✗'} |"
            )

    lines += [
        "",
        "## Evidence Plane",
        "",
        f"- Total contributions: {ep_summary.get('total_contributions', 0)}",
        f"- Boundary data points: {ep_summary.get('boundary_data_points', 0)}",
        f"- Geometry observable: {ep_summary.get('geometry_observable', False)}",
        "",
        "### By Region",
        "",
    ]
    for region, count in (ep_summary.get("by_region") or {}).items():
        lines.append(f"- `{region}`: {count}")

    write_text(path, "\n".join(lines) + "\n")


def write_run_summary_md(
    claude_result: dict,
    openai_result: dict,
    path_results: dict,
    ep_summary: dict,
    path: str,
    run_number: int = 0,
) -> None:
    claude_ok = claude_result.get("schema_valid", False)
    openai_ok = openai_result.get("schema_valid", False)
    paths_ok = sum(1 for v in (path_results or {}).values()
                   if v and v.get("pass"))
    paths_total = len(path_results or {})
    overall = "PASS" if (claude_ok and openai_ok and paths_ok == paths_total) \
              else ("PARTIAL" if (claude_ok or openai_ok or paths_ok > 0) \
              else "FAIL")

    lines = [
        f"# SV002 Diagnostic Run Summary",
        f"",
        f"**Run:** #{run_number}",
        f"**Status:** {overall}",
        f"**Timestamp:** {now_utc()}",
        f"",
        f"## Quick Status",
        f"",
        f"- Claude API: {'✓ OK' if claude_ok else '✗ FAIL'} "
        f"({claude_result.get('round_trip_ms', 0)}ms)",
        f"- OpenAI API: {'✓ OK' if openai_ok else '✗ FAIL'} "
        f"({openai_result.get('round_trip_ms', 0)}ms)",
        f"- Path tests: {paths_ok}/{paths_total} passed",
        f"- Evidence plane: "
        f"{ep_summary.get('total_contributions', 0)} contributions",
        f"",
        f"See `claude_test.md`, `chatgpt_test.md`, `merged.md` for details.",
    ]
    write_text(path, "\n".join(lines) + "\n")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--anthropic-api-key", default=os.environ.get(
        "ANTHROPIC_API_KEY", ""
    ))
    parser.add_argument("--openai-api-key", default=os.environ.get(
        "OPENAI_API_KEY", ""
    ))
    parser.add_argument("--diag-dir", default="diagnostics")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    results_dir = os.path.join(args.diag_dir, "results")
    current_dir = os.path.join(results_dir, "current")
    previous_dir = os.path.join(results_dir, "previous")
    task_md_path = os.path.join(args.diag_dir, "diagnostic_task.md")

    # Roll current → previous
    if os.path.exists(current_dir) and os.listdir(current_dir):
        if os.path.exists(previous_dir):
            shutil.rmtree(previous_dir)
        shutil.copytree(current_dir, previous_dir)
        shutil.rmtree(current_dir)
    os.makedirs(current_dir, exist_ok=True)

    # Determine run number
    run_record_path = os.path.join(results_dir, "run_count.json")
    run_number = 1
    if os.path.exists(run_record_path):
        try:
            run_number = json.load(open(run_record_path)).get("count", 0) + 1
        except Exception:
            pass
    write_json(run_record_path, {"count": run_number, "last_utc": now_utc()})

    # Load task.md
    task_md = ""
    if os.path.exists(task_md_path):
        with open(task_md_path) as f:
            task_md = f.read()
    else:
        task_md = "Respond with a valid stegverse.candidate_patch.v1 JSON block for provider=YOUR_PROVIDER."

    print(f"Run #{run_number} — {now_utc()}")

    # LLM health checks
    print("Checking Claude API...")
    claude_result = check_claude(args.anthropic_api_key, task_md, current_dir)
    print(f"  Claude: {'OK' if claude_result['schema_valid'] else 'FAIL'} "
          f"({claude_result['round_trip_ms']}ms)")

    print("Checking OpenAI API...")
    openai_result = check_openai(args.openai_api_key, task_md, current_dir)
    print(f"  OpenAI: {'OK' if openai_result['schema_valid'] else 'FAIL'} "
          f"({openai_result['round_trip_ms']}ms)")

    # Path tests
    print("Running path tests...")
    path_results = run_path_tests(current_dir, dry_run=True)
    paths_ok = sum(1 for v in path_results.values() if v and v.get("pass"))
    print(f"  Paths: {paths_ok}/{len(path_results)} passed")

    # Evidence plane summary
    ep_summary = {}
    try:
        from core_lite.batch_ingestion.evidence_plane import EvidencePlaneBuilder
        ep = EvidencePlaneBuilder(
            evidence_plane_root="tracking/evidence_plane",
            receipt_dir=current_dir,
        )
        ep_summary = ep.summarize()
    except ImportError:
        ep_summary = {"total_contributions": 0, "boundary_data_points": 0,
                      "geometry_observable": False, "by_region": {}}

    # Write outputs
    write_provider_md(claude_result,
                      os.path.join(current_dir, "claude_test.md"))
    write_provider_md(openai_result,
                      os.path.join(current_dir, "chatgpt_test.md"))
    write_merged_md(claude_result, openai_result, path_results, ep_summary,
                    os.path.join(current_dir, "merged.md"))
    write_run_summary_md(claude_result, openai_result, path_results, ep_summary,
                         os.path.join(current_dir, "run_summary.md"),
                         run_number=run_number)

    write_json(os.path.join(current_dir, "candidate_validation.json"), {
        "schema": "stegverse.diagnostic_candidate_validation.v1",
        "timestamp_utc": now_utc(),
        "run": run_number,
        "claude": {k: v for k, v in claude_result.items()
                   if k not in ("raw_response", "candidate")},
        "openai": {k: v for k, v in openai_result.items()
                   if k not in ("raw_response", "candidate")},
    })

    write_json(os.path.join(current_dir, "path_test_report.json"), {
        "schema": "stegverse.diagnostic_path_test_report.v1",
        "timestamp_utc": now_utc(),
        "run": run_number,
        "paths": path_results,
        "passed": paths_ok,
        "total": len(path_results),
    })

    write_json(os.path.join(current_dir, "evidence_plane_summary.json"),
               {"schema": "stegverse.diagnostic_ep_summary.v1",
                "timestamp_utc": now_utc(),
                "run": run_number,
                **ep_summary})

    # Write to org receipt chain
    receipt = {
        "schema": "stegverse.diagnostic_receipt.v1",
        "timestamp_utc": now_utc(),
        "run": run_number,
        "claude_ok": claude_result["schema_valid"],
        "openai_ok": openai_result["schema_valid"],
        "claude_ms": claude_result["round_trip_ms"],
        "openai_ms": openai_result["round_trip_ms"],
        "paths_passed": paths_ok,
        "paths_total": len(path_results),
        "ep_contributions": ep_summary.get("total_contributions", 0),
        "overall": "PASS" if (claude_result["schema_valid"] and
                              openai_result["schema_valid"] and
                              paths_ok == len(path_results)) else "PARTIAL"
                   if (claude_result["schema_valid"] or
                       openai_result["schema_valid"] or paths_ok > 0)
                   else "FAIL",
    }
    append_jsonl("receipts/current/diagnostic_receipt.jsonl", receipt)

    # Summary output for task dispatcher
    print(json.dumps({
        "status": "success" if receipt["overall"] == "PASS" else "partial",
        "run": run_number,
        "claude_ok": receipt["claude_ok"],
        "openai_ok": receipt["openai_ok"],
        "paths_passed": paths_ok,
        "paths_total": len(path_results),
        "overall": receipt["overall"],
    }, indent=2))

    sys.exit(0 if receipt["overall"] in ("PASS", "PARTIAL") else 1)


if __name__ == "__main__":
    main()
