# SV002 M11 Disposition Gate Test Payload — 20260528T235307Z

This is a fresh documentation-only payload for testing the incoming disposition gate.

## Purpose

This payload should prove that the current workflow:

1. selects only the changed payload pushed into `incoming/`;
2. computes a SHA-256 hash;
3. stages a copy under `tracking/incoming_mailbox/<sha>/`;
4. evaluates the staged payload;
5. writes a disposition record;
6. removes only this dispositioned changed payload from `incoming/`;
7. inventories legacy incoming payloads without deleting them.

## Expected upload path

```text
incoming/sv002_m11_disposition_gate_test_payload_20260528t235307z.zip
```

## Expected durable evidence

```text
reports/current/incoming_changed_files.txt
reports/current/incoming_legacy_inventory.txt
reports/current/incoming_disposition_summary.jsonl
receipts/current/incoming_disposition_receipt.jsonl
tracking/incoming_mailbox/<sha>/
```

If evaluation fails, the staged payload should also be copied to:

```text
quarantine/incoming/<sha>/
```

## Safety

This payload contains no workflow files, no executable code, no secrets, no root README replacement, and no authority expansion.
