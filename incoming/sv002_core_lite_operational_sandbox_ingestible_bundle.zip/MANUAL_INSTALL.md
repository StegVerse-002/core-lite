# Manual Install — StegVerse-002 Core-Lite Operational Sandbox

## Target

Repository: `StegVerse-002/core-lite`  
Branch: `main`  
Stage: `SV002-M10`

## Install

Upload the bundled files to the exact paths shown in `bundle_manifest.json`.

This bundle intentionally adds a sandbox that reasons about outcomes without binding external consequence. It does not authorize sending email, posting to social media, pushing repo changes, deploying, publishing, deleting, forwarding, scheduling, or any other external effect.

## Verify

Run:

```bash
python -m core_lite.sandbox \
  --repo-root . \
  --plan examples/sandbox_plan.example.json \
  --entity StegVerse-002 \
  --stage SV002-M10
```

Then confirm these files exist:

```text
reports/current/sandbox_result.json
dist/current/sandbox_response_candidate.json
receipts/current/sandbox_receipt.jsonl
```

Optional dispatcher verification:

```bash
python -m tools.scripts.task_dispatcher \
  --task-id sandbox.reason.outcomes \
  --task-catalog tools/tasks/task_catalog.json \
  --entity StegVerse-002 \
  --stage SV002-M10
```

Optional test verification:

```bash
pytest tests/test_sandbox.py -q
```

## Release tag reminder

Do not create the tag until verification passes. After proof succeeds, create:

```text
v1.1.0-sv002-sandbox
```
