# iosnoperiod Mapping Note

This bundle includes `iosnoperiod.md` for StegVerse bundle-standard compliance.

No canonical file or directory path in this bundle begins with a leading period (`.`), so no mirrored `iosnoperiod/` tree is required for this specific bundle.

When a future bundle includes canonical leading-dot paths such as `.github/workflows/...`, the bundle must also include an iOS-safe mirror under `iosnoperiod/` with no periods anywhere in the mirrored path. In that convention, `iosnoperiod/` maps to repository root for manual placement.
