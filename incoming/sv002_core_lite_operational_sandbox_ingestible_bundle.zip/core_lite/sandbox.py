"""
core_lite.sandbox — StegVerse-002 operational sandbox.

The sandbox reasons about candidate outcomes without binding consequence.
It may classify inputs, simulate proposed responses, and emit reports/receipts.
It must not send email, post publicly, push commits, deploy, delete, or mutate
external targets.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from core_lite.cge import CGEEngine, CGERequest, classify_sandbox_result
from core_lite.receipts import append_receipt

SANDBOX_SCHEMA = "stegverse.sandbox_plan.v1"
RESULT_SCHEMA = "stegverse.sandbox_result.v1"
RESPONSE_SCHEMA = "stegverse.response_candidate.v1"

ALLOWED_SANDBOX_ACTIONS = {
    "classify_input",
    "reason_about_outcome",
    "generate_response_candidate",
    "preserve_evidence",
    "request_human_approval",
    "no_action",
}

CONSEQUENCE_BEARING_VERBS = {
    "send",
    "post",
    "publish",
    "comment",
    "reply",
    "forward",
    "delete",
    "archive",
    "label",
    "commit",
    "push",
    "merge",
    "release",
    "deploy",
    "invoice",
    "pay",
    "schedule",
    "invite",
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def stable_hash(payload: Any) -> str:
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    return "sha256:" + hashlib.sha256(encoded).hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, sort_keys=True)
        f.write("\n")


@dataclass
class SandboxFinding:
    finding_id: str
    severity: str
    statement: str
    required_control: str


@dataclass
class OutcomeProjection:
    action_id: str
    proposed_action: str
    predicted_result: str
    consequence_level: str
    human_required: bool
    admissibility_pressure: str
    recoverability: str
    notes: list[str] = field(default_factory=list)


class OperationalSandbox:
    def __init__(self, repo_root: Path, entity: str, stage: str, dry_run: bool = False):
        self.repo_root = Path(repo_root)
        self.entity = entity
        self.stage = stage
        self.dry_run = dry_run

    def run(self, plan_path: Path) -> dict[str, Any]:
        plan = load_json(plan_path)
        plan_hash = stable_hash(plan)
        validation = self._validate_plan(plan)

        cge_result = CGEEngine(self.repo_root).decide(
            CGERequest(
                actor=self.entity,
                stage=self.stage,
                target_scope="core-lite/sandbox",
                action="sandbox_outcome_reasoning",
                input_type="structured_data",
                privacy_class=plan.get("privacy_class", "private"),
                allowed_use=["context", "report", "candidate_preparation", "sandbox_reasoning"],
                forbidden_use=["training", "publication", "production_mutation", "external_effect"],
                stop_condition="Sandbox result classified. Response candidate produced without production binding.",
                dry_run=True,
                metadata={"plan_hash": plan_hash, "sandbox_id": plan.get("sandbox_id", "")},
            )
        )

        findings = self._build_findings(plan, validation, cge_result.decision)
        projections = self._project_outcomes(plan)
        response_candidate = self._build_response_candidate(plan, plan_hash, projections, findings)

        status = "success" if validation["valid"] and cge_result.decision in {"ALLOW", "SANDBOX", "REVIEW_REQUIRED"} else "failure"
        cge_classification = classify_sandbox_result({"status": status})

        result = {
            "schema": RESULT_SCHEMA,
            "timestamp": utc_now(),
            "entity": self.entity,
            "stage": self.stage,
            "sandbox_id": plan.get("sandbox_id", "sandbox-default"),
            "plan_path": str(plan_path),
            "plan_hash": plan_hash,
            "status": status,
            "dry_run": self.dry_run,
            "mutation_to_target_performed": False,
            "external_effects_performed": False,
            "validation": validation,
            "cge_precheck": cge_result.to_dict(),
            "cge_classification": cge_classification,
            "findings": [asdict(f) for f in findings],
            "outcome_projections": [asdict(p) for p in projections],
            "response_candidate_path": "dist/current/sandbox_response_candidate.json",
            "stop_condition_met": True,
            "stop_condition": "Sandbox result classified. No production/public/private/repo consequence was bound.",
        }

        write_json(self.repo_root / "reports/current/sandbox_result.json", result)
        write_json(self.repo_root / "dist/current/sandbox_response_candidate.json", response_candidate)

        receipt = append_receipt(
            str(self.repo_root / "receipts/current/sandbox_receipt.jsonl"),
            actor=self.entity,
            stage=self.stage,
            gate="operational_sandbox",
            task_id="sandbox.reason.outcomes",
            action="sandbox_outcome_reasoning",
            decision=cge_classification,
            basis="Operational sandbox produced outcome projections and response candidate without external effects.",
            input_type="structured_data",
            input_hash=plan_hash,
            privacy_class=plan.get("privacy_class", "private"),
            allowed_use=["context", "report", "candidate_preparation", "sandbox_reasoning"],
            forbidden_use=["training", "publication", "production_mutation", "external_effect"],
            stop_condition=result["stop_condition"],
            mutation_to_target_performed=False,
            outputs=[
                "reports/current/sandbox_result.json",
                "dist/current/sandbox_response_candidate.json",
            ],
        )
        result["receipt_hash"] = receipt.receipt_hash
        write_json(self.repo_root / "reports/current/sandbox_result.json", result)
        return result

    def _validate_plan(self, plan: dict[str, Any]) -> dict[str, Any]:
        errors: list[str] = []
        if plan.get("schema") != SANDBOX_SCHEMA:
            errors.append(f"schema must equal {SANDBOX_SCHEMA}")
        if plan.get("entity") not in (None, "", self.entity):
            errors.append("plan entity must match active sandbox entity")
        if not plan.get("objective"):
            errors.append("objective is required")
        if not isinstance(plan.get("input_events", []), list):
            errors.append("input_events must be a list")
        proposed_actions = plan.get("proposed_actions", [])
        if not isinstance(proposed_actions, list) or not proposed_actions:
            errors.append("proposed_actions must be a non-empty list")
        for idx, action in enumerate(proposed_actions):
            action_type = action.get("action_type", "")
            if action_type not in ALLOWED_SANDBOX_ACTIONS:
                errors.append(f"proposed_actions[{idx}].action_type is not allowed: {action_type}")
            if action.get("external_effect") is True:
                errors.append(f"proposed_actions[{idx}] requests external_effect=true")
        return {
            "valid": not errors,
            "errors": errors,
            "allowed_sandbox_actions": sorted(ALLOWED_SANDBOX_ACTIONS),
        }

    def _build_findings(self, plan: dict[str, Any], validation: dict[str, Any], cge_decision: str) -> list[SandboxFinding]:
        findings: list[SandboxFinding] = []
        if not validation["valid"]:
            findings.append(SandboxFinding(
                finding_id="sandbox.validation.failure",
                severity="high",
                statement="Sandbox plan failed validation.",
                required_control="Do not generate an actionable response until the plan is corrected.",
            ))
        if cge_decision not in {"ALLOW", "SANDBOX", "REVIEW_REQUIRED"}:
            findings.append(SandboxFinding(
                finding_id="sandbox.cge.blocked",
                severity="high",
                statement=f"CGE precheck returned {cge_decision}.",
                required_control="Fail closed or route to human review before any candidate is used.",
            ))
        if self._plan_has_consequence_bearing_output(plan):
            findings.append(SandboxFinding(
                finding_id="sandbox.human.required",
                severity="medium",
                statement="One or more proposed outputs could bind public, private, relational, financial, calendar, email, social, or repository consequence.",
                required_control="Treat generated output as HUMAN_REQUIRED until explicitly approved by the human/operator authority.",
            ))
        if not findings:
            findings.append(SandboxFinding(
                finding_id="sandbox.nominal",
                severity="low",
                statement="Sandbox plan is valid and remained consequence-free.",
                required_control="Preserve reports and receipts before considering promotion.",
            ))
        return findings

    def _project_outcomes(self, plan: dict[str, Any]) -> list[OutcomeProjection]:
        projections: list[OutcomeProjection] = []
        for idx, action in enumerate(plan.get("proposed_actions", []), start=1):
            action_id = action.get("action_id") or f"action-{idx}"
            description = action.get("description", action.get("action_type", "unspecified"))
            consequence_level = action.get("consequence_level", "low")
            human_required = bool(action.get("requires_human_approval", False)) or consequence_level in {"medium", "high"}
            if self._text_contains_consequence_verb(description):
                human_required = True
                consequence_level = "medium" if consequence_level == "low" else consequence_level
            pressure = "review_pressure" if human_required else "sandbox_only"
            recoverability = "recoverable_if_not_bound" if human_required else "recoverable"
            projections.append(OutcomeProjection(
                action_id=action_id,
                proposed_action=description,
                predicted_result=self._predict_result(action),
                consequence_level=consequence_level,
                human_required=human_required,
                admissibility_pressure=pressure,
                recoverability=recoverability,
                notes=[
                    "Projection is advisory only.",
                    "No external system was mutated by this sandbox run.",
                ],
            ))
        return projections

    def _build_response_candidate(
        self,
        plan: dict[str, Any],
        plan_hash: str,
        projections: list[OutcomeProjection],
        findings: list[SandboxFinding],
    ) -> dict[str, Any]:
        human_required = any(p.human_required for p in projections) or any(f.finding_id == "sandbox.human.required" for f in findings)
        return {
            "schema": RESPONSE_SCHEMA,
            "timestamp": utc_now(),
            "entity": self.entity,
            "stage": self.stage,
            "source_sandbox_id": plan.get("sandbox_id", "sandbox-default"),
            "source_plan_hash": plan_hash,
            "candidate_type": plan.get("candidate_type", "sandbox_response"),
            "admissibility_status": "HUMAN_REQUIRED" if human_required else "ALLOW_CANDIDATE_ONLY",
            "human_required": human_required,
            "external_effects_allowed": False,
            "mutation_allowed": False,
            "publication_allowed": False,
            "summary": self._summarize(plan, projections, human_required),
            "recommended_next_action": "request_human_approval" if human_required else "preserve_evidence",
            "outcome_projection_count": len(projections),
            "finding_count": len(findings),
            "proposed_response": plan.get("draft_response", "No direct response supplied. Sandbox produced outcome projections only."),
            "required_controls": sorted({f.required_control for f in findings}),
        }

    def _predict_result(self, action: dict[str, Any]) -> str:
        action_type = action.get("action_type", "")
        if action_type == "classify_input":
            return "Input becomes structured evidence but does not authorize a response."
        if action_type == "reason_about_outcome":
            return "Likely outcomes are projected for review before any consequence binds."
        if action_type == "generate_response_candidate":
            return "A response candidate is prepared for approval, not execution."
        if action_type == "preserve_evidence":
            return "Evidence is retained with receipts for replay/reconstruction."
        if action_type == "request_human_approval":
            return "Human/operator authority is asked to approve, revise, or deny the candidate."
        if action_type == "no_action":
            return "No external consequence is prepared."
        return "Unknown sandbox action; review required."

    def _summarize(self, plan: dict[str, Any], projections: list[OutcomeProjection], human_required: bool) -> str:
        objective = plan.get("objective", "unspecified objective")
        count = len(projections)
        boundary = "human approval is required before consequence" if human_required else "candidate may be preserved as evidence"
        return f"Sandbox evaluated {count} proposed action(s) for: {objective}. Result: {boundary}."

    def _plan_has_consequence_bearing_output(self, plan: dict[str, Any]) -> bool:
        for action in plan.get("proposed_actions", []):
            if action.get("consequence_level") in {"medium", "high"}:
                return True
            if action.get("requires_human_approval") is True:
                return True
            if self._text_contains_consequence_verb(action.get("description", "")):
                return True
        if self._text_contains_consequence_verb(plan.get("draft_response", "")):
            return True
        return False

    def _text_contains_consequence_verb(self, text: str) -> bool:
        lowered = text.lower()
        return any(verb in lowered for verb in CONSEQUENCE_BEARING_VERBS)


def main() -> None:
    parser = argparse.ArgumentParser(prog="core_lite.sandbox")
    parser.add_argument("--repo-root", default=".")
    parser.add_argument("--plan", default="examples/sandbox_plan.example.json")
    parser.add_argument("--entity", default="StegVerse-002")
    parser.add_argument("--stage", default="SV002-M10")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    sandbox = OperationalSandbox(
        repo_root=Path(args.repo_root),
        entity=args.entity,
        stage=args.stage,
        dry_run=args.dry_run,
    )
    result = sandbox.run(Path(args.plan))
    print(json.dumps(result, indent=2, sort_keys=True))
    raise SystemExit(0 if result.get("status") == "success" else 1)


if __name__ == "__main__":
    main()
