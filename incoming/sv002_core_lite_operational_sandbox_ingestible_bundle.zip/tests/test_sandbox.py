import json
from pathlib import Path

from core_lite.sandbox import OperationalSandbox


def test_operational_sandbox_generates_human_required_candidate(tmp_path: Path):
    plan = {
        "schema": "stegverse.sandbox_plan.v1",
        "entity": "StegVerse-002",
        "stage": "SV002-M10",
        "sandbox_id": "test-sandbox",
        "privacy_class": "private",
        "objective": "Test governed outcome reasoning.",
        "input_events": [
            {
                "event_id": "input-001",
                "source": "test",
                "input_type": "strategic_instruction",
                "summary": "Prepare a response candidate."
            }
        ],
        "proposed_actions": [
            {
                "action_id": "candidate-001",
                "action_type": "generate_response_candidate",
                "description": "Generate a response candidate for a future public post only after approval.",
                "consequence_level": "medium",
                "requires_human_approval": True,
                "external_effect": False
            }
        ]
    }
    plan_path = tmp_path / "plan.json"
    plan_path.write_text(json.dumps(plan), encoding="utf-8")

    result = OperationalSandbox(tmp_path, "StegVerse-002", "SV002-M10").run(plan_path)

    candidate = json.loads((tmp_path / "dist/current/sandbox_response_candidate.json").read_text())
    receipt = (tmp_path / "receipts/current/sandbox_receipt.jsonl").read_text().strip()

    assert result["status"] == "success"
    assert result["external_effects_performed"] is False
    assert result["mutation_to_target_performed"] is False
    assert candidate["admissibility_status"] == "HUMAN_REQUIRED"
    assert receipt
