# StegVerse-002 Operational Sandbox

## Assumptions

- `StegVerse-002/core-lite` remains the clean proof target.
- The existing workflow dispatcher remains stable; no new workflow file is required.
- The sandbox is not a production executor.
- The sandbox may reason about outcomes, classify risk, and prepare response candidates.
- The sandbox may not send, post, publish, commit, deploy, delete, schedule, invite, or mutate an external target.

## Done condition

The sandbox is operationally sound when it can:

1. Ingest a structured sandbox plan.
2. Validate the plan against the allowed sandbox action surface.
3. Route the plan through CGE precheck.
4. Produce outcome projections.
5. Produce a response candidate.
6. Mark consequence-bearing candidates as `HUMAN_REQUIRED`.
7. Emit a sandbox result report.
8. Emit an append-only sandbox receipt.
9. Stop without binding any public, private, financial, social, calendar, email, or repository consequence.

## Capability boundary

The operational sandbox exists to let StegVerse-002 reason about outcomes before ecosystem progress binds into reality.

The sandbox may prepare consequence, but it may not execute consequence.

```text
input signal
→ governed ingestion
→ sandbox plan
→ CGE precheck
→ outcome projection
→ response candidate
→ HUMAN_REQUIRED when consequence-bearing
→ receipt
→ stop
```

## Task entry point

Run through the existing dispatcher:

```bash
python -m tools.scripts.task_dispatcher \
  --task-id sandbox.reason.outcomes \
  --task-catalog tools/tasks/task_catalog.json \
  --entity StegVerse-002 \
  --stage SV002-M10
```

Run directly:

```bash
python -m core_lite.sandbox \
  --repo-root . \
  --plan examples/sandbox_plan.example.json \
  --entity StegVerse-002 \
  --stage SV002-M10
```

## Outputs

```text
reports/current/sandbox_result.json
receipts/current/sandbox_receipt.jsonl
dist/current/sandbox_response_candidate.json
```

## Governance rule

Every interface that can influence ecosystem progress is a governed input.
Every response created from ingestion is a proposed transition.
No proposed transition becomes consequence-bearing until admissibility is checked and required human/operator authority is present.
