# SV002 M10.5/M11 Validation Bundle

**Purpose:** Synthetic validation bundle. Proves the M10.5 candidate review
path and M11 apply gate are operational in the live dispatcher.

**Not a real transition.** No capability is installed by this bundle.
This document is the only payload.

**Expected outcomes:**
- M10.5 review: `ALLOW_CANDIDATE_REVIEW`
- M11 gate (dry_run=true): `ALLOW`
- M11 gate (dry_run=false): `DEFER` (Triad stubs unresolved — correct behavior)
