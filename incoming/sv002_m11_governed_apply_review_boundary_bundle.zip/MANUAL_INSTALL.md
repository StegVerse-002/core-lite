# Manual Install — SV002 M11 Governed Apply Review Boundary

Upload this ZIP to:

```text
incoming/sv002_m11_governed_apply_review_boundary_bundle.zip
```

Run `core-lite-intake` with:

```text
task_id: [blank]
skip_tasks: false
stage_override: SV002-M10
input_type: bundle
input_path: incoming/sv002_m11_governed_apply_review_boundary_bundle.zip
kv_packet: [blank]
dry_run: false
agent_provider: none
```

After ingestion, run the installed M11 task with:

```text
task_id: stegverse.apply.review
skip_tasks: false
stage_override: SV002-M10
input_type: [blank]
input_path: [blank]
kv_packet: [blank]
dry_run: false
agent_provider: none
```

Expected first M11 decision:

```text
DENY_APPLY
```

That denial is intentional because the example request has:

```text
operator_approved: false
```

This proves default-deny at the apply/review boundary.
