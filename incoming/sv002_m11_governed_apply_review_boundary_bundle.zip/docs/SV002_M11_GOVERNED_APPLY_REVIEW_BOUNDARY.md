# SV002-M11 — Governed Apply / Review Boundary

## Status

Ingestible M11 seed bundle.

## Purpose

M10 proved that StegVerse can become the official governed output authority while LLM provider outputs remain candidate evidence only.

M11 adds the next boundary:

> A StegVerse-governed output may recommend a repository mutation, but it is still not execution authority.

A separate apply/review gate must validate the request before any mutation can be considered admissible.

## Principle

No entity receives broad authority.

Every apply request must be scoped, staged, explicit, receipted, bounded by transition class, checked at the commit/execution boundary, recoverable, containable, and denied by default unless specifically granted.

## Installed Files

This bundle installs:

- `scripts/stegverse_apply_gate.py`
- `schemas/apply_request.schema.json`
- `schemas/apply_review.schema.json`
- `examples/apply_request.example.json`
- `docs/SV002_M11_GOVERNED_APPLY_REVIEW_BOUNDARY.md`
- `tests/test_stegverse_apply_gate.py`
- `tools/tasks/task_catalog.json`

## Gate Behavior

The gate reads an apply request and emits:

- `outputs/stegverse_apply_review.md`
- `reports/current/stegverse_apply_review_report.json`
- `receipts/current/stegverse_apply_review_receipt.jsonl`
- `dist/run_artifacts/stegverse-apply-review.zip`

The gate denies by default unless:

1. `operator_approved` is true.
2. The request has an explicit `authority_ref`.
3. The request has an explicit `policy_ref`.
4. The request has an explicit `task_id`.
5. The requested transition class is allowed.
6. Every proposed path is inside the allowed path set.
7. Required evidence paths exist.
8. The repo already contains `outputs/stegverse_output.md`.

## Non-Goal

This M11 seed does **not** apply file mutations.

It only reviews whether an apply request is admissible. Actual mutation is a later transition after this boundary is proven.

## Verification Task

After ingestion, run:

```text
task_id: stegverse.apply.review
skip_tasks: false
stage_override: SV002-M10
input_type: [blank]
input_path: [blank]
dry_run: false
agent_provider: none
```

The included example request intentionally lacks operator approval, so the expected decision is:

```text
DENY_APPLY
```

That is the correct first proof: the apply gate exists and denies by default.
