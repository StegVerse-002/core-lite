# iOS No-Period Mirror

This bundle does not install any leading-period canonical paths.

`iosnoperiod/` is included only to preserve the StegVerse bundle convention that every bundle can carry an iOS-safe mirror when needed.

For this bundle, the mirror is empty because all canonical paths are normal repository paths.
