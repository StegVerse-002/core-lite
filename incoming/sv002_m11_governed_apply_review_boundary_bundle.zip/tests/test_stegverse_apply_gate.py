import json
import subprocess
import sys
from pathlib import Path


def test_apply_gate_denies_without_operator_approval(tmp_path):
    repo = tmp_path
    (repo / "scripts").mkdir()
    source = Path(__file__).resolve().parents[1] / "scripts" / "stegverse_apply_gate.py"
    target = repo / "scripts" / "stegverse_apply_gate.py"
    target.write_text(source.read_text())

    (repo / "examples").mkdir()
    request = {
        "task_id": "stegverse.apply.review",
        "transition_class": "documentation",
        "authority_ref": "test-authority",
        "policy_ref": "test-policy",
        "operator_approved": False,
        "proposed_paths": ["docs/example.md"],
        "evidence_paths": []
    }
    (repo / "examples" / "apply_request.example.json").write_text(json.dumps(request))

    result = subprocess.run(
        [sys.executable, "scripts/stegverse_apply_gate.py", "--repo-root", ".", "--request", "examples/apply_request.example.json"],
        cwd=repo,
        text=True,
        capture_output=True,
        check=True,
    )
    report = json.loads((repo / "reports/current/stegverse_apply_review_report.json").read_text())
    assert report["decision"] == "DENY_APPLY"
    assert (repo / "outputs/stegverse_apply_review.md").exists()
    assert (repo / "receipts/current/stegverse_apply_review_receipt.jsonl").exists()
    assert (repo / "dist/run_artifacts/stegverse-apply-review.zip").exists()
