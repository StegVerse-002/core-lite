#!/usr/bin/env python3
"""StegVerse M11 apply/review gate.

This gate reviews whether a proposed repository mutation is admissible.
It does not apply mutations. It emits a report, receipt, markdown summary,
and zipped run artifact.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import hashlib
import json
import sys
import zipfile
from pathlib import Path
from typing import Any

SCHEMA_VERSION = "stegverse.apply_review.v1"
DEFAULT_ALLOWED_PREFIXES = (
    "docs/",
    "schemas/",
    "scripts/",
    "tests/",
    "tools/",
    "examples/",
    "outputs/",
    "reports/current/",
    "receipts/current/",
    "dist/run_artifacts/",
    "tracking/",
    "agent_history/",
)
FORBIDDEN_PREFIXES = (
    ".github/workflows/",
    "incoming/",
    ".git/",
)
REPORT_PATH = Path("reports/current/stegverse_apply_review_report.json")
RECEIPT_PATH = Path("receipts/current/stegverse_apply_review_receipt.jsonl")
OUTPUT_MD = Path("outputs/stegverse_apply_review.md")
ARTIFACT_PATH = Path("dist/run_artifacts/stegverse-apply-review.zip")


def utc_now() -> str:
    return _dt.datetime.now(_dt.timezone.utc).isoformat()


def canonical_json(data: Any) -> str:
    return json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_text(text: str) -> str:
    return "sha256:" + hashlib.sha256(text.encode("utf-8")).hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise SystemExit(f"request file not found: {path}")
    except json.JSONDecodeError as exc:
        raise SystemExit(f"request file is not valid JSON: {path}: {exc}")


def path_allowed(path: str, allowed_prefixes: tuple[str, ...]) -> tuple[bool, str]:
    clean = path.strip().replace("\\", "/")
    if not clean or clean.startswith("/") or ".." in Path(clean).parts:
        return False, "path must be relative and must not contain traversal"
    if any(clean == p.rstrip("/") or clean.startswith(p) for p in FORBIDDEN_PREFIXES):
        return False, "path is inside forbidden prefix"
    if not any(clean == p.rstrip("/") or clean.startswith(p) for p in allowed_prefixes):
        return False, "path is outside allowed prefixes"
    return True, "allowed"


def evaluate(repo_root: Path, request: dict[str, Any], request_path: Path) -> dict[str, Any]:
    allowed_prefixes = tuple(request.get("allowed_path_prefixes") or DEFAULT_ALLOWED_PREFIXES)
    proposed_paths = list(request.get("proposed_paths") or [])
    evidence_paths = list(request.get("evidence_paths") or [])

    checks: list[dict[str, Any]] = []

    def add_check(name: str, passed: bool, detail: str) -> None:
        checks.append({"name": name, "passed": bool(passed), "detail": detail})

    operator_approved = bool(request.get("operator_approved", False))
    add_check("operator_approved", operator_approved, "operator approval flag must be true")

    authority_ref = str(request.get("authority_ref", "")).strip()
    add_check("authority_ref", bool(authority_ref), authority_ref or "missing authority_ref")

    policy_ref = str(request.get("policy_ref", "")).strip()
    add_check("policy_ref", bool(policy_ref), policy_ref or "missing policy_ref")

    task_id = str(request.get("task_id", "")).strip()
    add_check("task_id", bool(task_id), task_id or "missing task_id")

    transition_class = str(request.get("transition_class", "")).strip()
    allowed_transition_classes = set(request.get("allowed_transition_classes") or ["documentation", "schema", "test", "tooling", "receipt"])
    add_check(
        "transition_class",
        transition_class in allowed_transition_classes,
        transition_class or "missing transition_class",
    )

    add_check("proposed_paths_present", bool(proposed_paths), f"{len(proposed_paths)} proposed path(s)")
    for p in proposed_paths:
        ok, detail = path_allowed(str(p), allowed_prefixes)
        add_check(f"path_allowed:{p}", ok, detail)

    governed_output = repo_root / "outputs/stegverse_output.md"
    add_check(
        "governed_output_present",
        governed_output.exists(),
        "outputs/stegverse_output.md present" if governed_output.exists() else "outputs/stegverse_output.md missing",
    )

    for p in evidence_paths:
        exists = (repo_root / str(p)).exists()
        add_check(f"evidence_present:{p}", exists, "present" if exists else "missing")

    broad_authority_terms = ["broad authority", "unrestricted", "all paths", "admin", "self-approve", "bypass"]
    blob = canonical_json(request).lower()
    broad_hits = [term for term in broad_authority_terms if term in blob]
    add_check(
        "no_broad_authority_terms",
        not broad_hits,
        "no broad authority terms detected" if not broad_hits else f"detected: {broad_hits}",
    )

    passed = all(c["passed"] for c in checks)
    decision = "ALLOW_APPLY_REVIEW" if passed else "DENY_APPLY"

    report = {
        "schema": SCHEMA_VERSION,
        "generated_at": utc_now(),
        "decision": decision,
        "authority": "review_only_no_mutation",
        "repo_root": str(repo_root),
        "request_path": str(request_path),
        "request_hash": sha256_text(canonical_json(request)),
        "task_id": task_id,
        "transition_class": transition_class,
        "operator_approved": operator_approved,
        "proposed_paths": proposed_paths,
        "evidence_paths": evidence_paths,
        "checks": checks,
        "summary": (
            "Apply request passed review boundary; no mutation was performed."
            if passed
            else "Apply request denied by review boundary; no mutation was performed."
        ),
    }
    report["report_hash"] = sha256_text(canonical_json(report))
    return report


def write_outputs(report: dict[str, Any]) -> None:
    REPORT_PATH.parent.mkdir(parents=True, exist_ok=True)
    RECEIPT_PATH.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_MD.parent.mkdir(parents=True, exist_ok=True)
    ARTIFACT_PATH.parent.mkdir(parents=True, exist_ok=True)

    REPORT_PATH.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    passed = [c for c in report["checks"] if c["passed"]]
    failed = [c for c in report["checks"] if not c["passed"]]

    md = [
        "# StegVerse M11 Apply Review",
        "",
        f"Generated: `{report['generated_at']}`",
        f"Decision: `{report['decision']}`",
        f"Authority: `{report['authority']}`",
        "",
        "## Summary",
        "",
        report["summary"],
        "",
        "## Check Totals",
        "",
        f"- Passed: `{len(passed)}`",
        f"- Failed: `{len(failed)}`",
        "",
        "## Failed Checks",
        "",
    ]
    if failed:
        for c in failed:
            md.append(f"- `{c['name']}` — {c['detail']}")
    else:
        md.append("- none")
    md.extend([
        "",
        "## Proposed Paths",
        "",
    ])
    for p in report.get("proposed_paths", []):
        md.append(f"- `{p}`")
    md.append("")
    OUTPUT_MD.write_text("\n".join(md) + "\n", encoding="utf-8")

    receipt = {
        "schema": "stegverse.apply_review_receipt.v1",
        "timestamp": utc_now(),
        "decision": report["decision"],
        "report_hash": report["report_hash"],
        "request_hash": report["request_hash"],
        "authority": "review_only_no_mutation",
    }
    with RECEIPT_PATH.open("a", encoding="utf-8") as fh:
        fh.write(canonical_json(receipt) + "\n")

    with zipfile.ZipFile(ARTIFACT_PATH, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in (OUTPUT_MD, REPORT_PATH, RECEIPT_PATH):
            if path.exists():
                zf.write(path, path.as_posix())


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Review a StegVerse apply request without applying mutation.")
    parser.add_argument("--repo-root", default=".", help="Repository root")
    parser.add_argument("--request", default="examples/apply_request.example.json", help="Apply request JSON")
    args = parser.parse_args(argv)

    repo_root = Path(args.repo_root).resolve()
    request_path = (repo_root / args.request).resolve()
    request = load_json(request_path)
    report = evaluate(repo_root, request, request_path)
    write_outputs(report)
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
