# iOS No-Period Mapping

This bundle contains no canonical leading-period paths.

If a future version includes paths such as `.github/workflows/...`, mirror them under `iosnoperiod/` with every leading period removed so iOS Files does not hide or strip the paths.

In this bundle, `iosnoperiod/` is intentionally not needed.
