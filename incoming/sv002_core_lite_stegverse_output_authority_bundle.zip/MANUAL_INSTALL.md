# Manual Install — StegVerse Output Authority Bundle

## Target repo

```text
StegVerse-002/core-lite
```

## Files

Place these files exactly:

```text
scripts/package_stegverse_governed_output.py
docs/STEGVERSE_OUTPUT_AUTHORITY.md
tools/tasks/task_catalog.json
```

## Verify

Run:

```bash
python -m py_compile scripts/package_stegverse_governed_output.py
python scripts/package_stegverse_governed_output.py --repo-root .
```

Expected outputs:

```text
outputs/stegverse_output.md
outputs/stegverse_output.json
reports/current/stegverse_output_report.json
receipts/current/stegverse_output_receipt.jsonl
dist/run_artifacts/stegverse-governed-output.zip
```

## Dispatcher task

After installing `tools/tasks/task_catalog.json`, the same behavior can be invoked with:

```bash
python -m tools.scripts.task_dispatcher \
  --task-id stegverse.output.package \
  --task-catalog tools/tasks/task_catalog.json \
  --entity StegVerse-002 \
  --stage SV002-M10
```

## Release tag

Do not tag yet. This bundle controls output authority. The sandbox release tag still waits for sandbox proof.
