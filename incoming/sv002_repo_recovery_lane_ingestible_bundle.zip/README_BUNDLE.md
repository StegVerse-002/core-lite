# SV002 Repo Recovery Lane Ingestible Bundle

This bundle installs the repo recovery audit/wrap lane through governed ingestion.

Core rule: cleanup may gather and wrap; ingestion decides destination; originals are not deleted.
