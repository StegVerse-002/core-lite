# SV002-M11 Task — Repo Recovery Wrap Lane

## Purpose

Build a governed repo-recovery lane for files or bundles that need to move but may not be moved directly by cleanup.

Core rule:

```text
No cleanup task may directly relocate unresolved semantic content to its final destination.

Any unresolved file or bundle requiring movement must be wrapped as a new manifest-bearing ingestion object, assigned an ephemeral recovery hash, and routed through governed ingestion.

Cleanup may only remove the original after an ingestion receipt proves final disposition.
```

## Active Task Family

```text
sv002.repo.recovery.audit
sv002.repo.recovery.wrap.dry_run
sv002.repo.recovery.wrap
sv002.repo.recovery.finalize
```

## Authority Split

```text
sv002.repo.recovery.audit
  read-only
  observes repo footprint
  writes report and receipt only

sv002.repo.recovery.wrap.dry_run
  read-only
  validates proposed recovery wrapping
  writes report and receipt only

sv002.repo.recovery.wrap
  scoped repo write
  creates manifest-bearing recovery bundles in incoming/recovery/
  does not install destination files
  does not delete originals

sv002.repo.recovery.finalize
  declared_not_implemented
  may only be implemented after successful disposition receipts can be linked
```

## Recovery Lifecycle

```text
repo object found misplaced, stranded, duplicated, or unresolved
→ audit classifies it
→ wrap task assigns recovery ID and ephemeral bundle hash
→ recovery manifest declares source, hash, reason, and route
→ recovery bundle is placed in incoming/recovery/
→ governed ingestion processes the recovery bundle
→ final disposition is receipted
→ original can only be removed by later finalize task after receipt
```

## Install Locations

```text
tools/scripts/repo_recovery_audit.py
tools/scripts/repo_recovery_wrap.py
tools/tasks/task_catalog.json
tools/tasks/task.md
```

## Workflow Dispatch Order

First run:

```text
task_id: sv002.repo.recovery.audit
skip_tasks: false
stage_override: SV002-M11
agent_provider: none
dry_run: false
input_type: blank
input_path: blank
```

Then run:

```text
task_id: sv002.repo.recovery.wrap.dry_run
skip_tasks: false
stage_override: SV002-M11
agent_provider: none
dry_run: false
input_type: blank
input_path: blank
```

If the dry-run report is acceptable, run:

```text
task_id: sv002.repo.recovery.wrap
skip_tasks: false
stage_override: SV002-M11
agent_provider: none
dry_run: false
input_type: blank
input_path: blank
```

## Non-Goals

This build does not delete originals.
This build does not install destination files.
This build does not modify workflow files.
This build does not grant broad cleanup authority.
This build does not implement finalize.
