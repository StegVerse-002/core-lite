#!/usr/bin/env python3
from __future__ import annotations
import argparse, datetime as dt, hashlib, json, zipfile
from pathlib import Path
def now(): return dt.datetime.now(dt.timezone.utc).isoformat()
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024), b''): h.update(b)
    return 'sha256:'+h.hexdigest()
def name(src, sh): return 'sv002_recovery_'+sh.replace('sha256:','')[:16]+'_'+src.replace('/','__').replace(' ','_').replace(':','_')+'.zip'
def manifest(rec,rid,payload):
    return {'schema':'stegverse.recovery_manifest.v1','recovery_id':rid,'entity':'StegVerse-002','stage':'SV002-M11','created_at':now(),'recovery_reason':rec.get('classification','repo_recovery'),'source_path':rec['path'],'source_sha256':rec['sha256'],'source_size_bytes':rec.get('size_bytes'),'payload_name':payload,'payload_sha256':rec['sha256'],'proposed_route':'governed_ingestion','destination_authority':'ingestion_controller_only','cleanup_allowed_after':'successful_disposition_receipt','original_delete_allowed':False,'governance':{'no_broad_authority':True,'wraps_for_ingestion_only':True,'does_not_install_destinations':True,'does_not_delete_originals':True,'ingestion_decides_destination':True}}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--repo-root',default='.'); ap.add_argument('--audit-report',default='reports/current/repo_recovery_audit_report.json'); ap.add_argument('--report-dir',default='reports/current'); ap.add_argument('--receipt-dir',default='receipts/current'); ap.add_argument('--incoming-recovery-dir',default='incoming/recovery'); ap.add_argument('--dry-run',action='store_true'); a=ap.parse_args()
    root=Path(a.repo_root).resolve(); audit=root/a.audit_report; rd=root/a.report_dir; cd=root/a.receipt_dir; inc=root/a.incoming_recovery_dir; rd.mkdir(parents=True,exist_ok=True); cd.mkdir(parents=True,exist_ok=True)
    if not a.dry_run: inc.mkdir(parents=True,exist_ok=True)
    if not audit.exists(): raise SystemExit('audit report missing: '+str(audit))
    data=json.loads(audit.read_text()); candidates=[r for r in data.get('records',[]) if r.get('proposed_action')=='wrap_for_ingestion']
    wrapped=[]; failed=[]
    for rec in candidates:
        source=root/rec['path']
        if not source.exists() or not source.is_file(): failed.append({'path':rec['path'],'reason':'source_missing'}); continue
        cur=sha(source)
        if cur!=rec.get('sha256'): failed.append({'path':rec['path'],'reason':'source_hash_changed','audit_sha256':rec.get('sha256'),'current_sha256':cur}); continue
        rid='sv002-recovery-'+cur.replace('sha256:','')[:16]; payload=Path(rec['path']).name; bn=name(rec['path'],cur); bp=inc/bn; man=manifest(rec,rid,payload)
        entry={'source_path':rec['path'],'source_sha256':cur,'recovery_id':rid,'bundle_path':bp.relative_to(root).as_posix(),'manifest_schema':man['schema'],'dry_run':a.dry_run,'original_deleted':False,'destination_installed':False}
        if not a.dry_run:
            with zipfile.ZipFile(bp,'w',compression=zipfile.ZIP_DEFLATED) as z:
                z.writestr('recovery_manifest.json',json.dumps(man,indent=2,sort_keys=True)+'\n')
                z.write(source,arcname='payload/'+payload)
                z.writestr('README_RECOVERY.md','# StegVerse Recovery Bundle\n\nCleanup wrapped this object. Ingestion decides final disposition. Originals are not deleted by this task.\n')
            entry['bundle_sha256']=sha(bp)
        wrapped.append(entry)
    decision='ALLOW' if not failed else 'FAIL_CLOSED'
    report={'schema':'stegverse.repo_recovery.wrap.v1','entity':'StegVerse-002','stage':'SV002-M11','generated_at':now(),'decision':decision,'dry_run':a.dry_run,'audit_report':audit.relative_to(root).as_posix(),'audit_report_sha256':sha(audit),'wrapped':wrapped,'failed':failed,'summary':{'candidates':len(candidates),'wrapped':len(wrapped),'failed':len(failed),'bundles_created':0 if a.dry_run else len(wrapped)},'governance':{'no_broad_authority':True,'does_not_delete_originals':True,'does_not_install_destinations':True,'wraps_for_ingestion_only':True,'ingestion_decides_destination':True}}
    rp=rd/'repo_recovery_wrap_report.json'; cp=cd/'repo_recovery_wrap_receipt.jsonl'; rp.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    receipt={'schema':'stegverse.repo_recovery.wrap_receipt.v1','timestamp_utc':now(),'decision':decision,'dry_run':a.dry_run,'report_path':rp.relative_to(root).as_posix(),'report_sha256':sha(rp),'wrapped':len(wrapped),'failed':len(failed),'originals_deleted':False,'destinations_installed':False,'authority':'read_only' if a.dry_run else 'scoped_repo_write'}
    with cp.open('a') as f: f.write(json.dumps(receipt,sort_keys=True)+'\n')
    print(json.dumps({'status':'success' if decision=='ALLOW' else 'fail_closed','decision':decision,'dry_run':a.dry_run,'report':rp.relative_to(root).as_posix(),'receipt':cp.relative_to(root).as_posix(),'summary':report['summary']},indent=2,sort_keys=True))
    return 0 if decision=='ALLOW' else 1
if __name__=='__main__': raise SystemExit(main())
