# StegVerse Recovery Bundle

Cleanup/recovery wrapped this object. Ingestion decides final disposition. Originals are not deleted by this task. The manifest declares a non-binding evidence transition.
