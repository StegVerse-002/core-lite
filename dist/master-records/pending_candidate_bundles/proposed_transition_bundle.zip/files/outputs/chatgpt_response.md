```json
{
  "schema": "stegverse.candidate_patch.v1",
  "candidate_id": "sv002-m11-pipeline-batch-ingestion-bridge",
  "provider": "OpenAI",
  "description": "Wire core_lite.multimodal.pipeline to route .zip bundles through BatchIngestionController",
  "transition_class": "candidate",
  "authority_ref": "SV002-M11/pipeline-batch-ingestion-bridge",
  "policy_ref": "triad/default-deny/no-broad-authority",
  "files": [
    {
      "path": "core_lite/multimodal/pipeline.py",
      "operation": "write",
      "content": "import os\nimport shutil\nfrom core_lite.batch_ingestion.controller import BatchIngestionController\n\nclass MultimodalPipeline:\n    def __init__(self):\n        self.batch_controller = BatchIngestionController()\n\n    def process_bundle(self, bundle_path):\n        if bundle_path.endswith('.zip'):\n            result = self.batch_controller.ingest(bundle_path)\n            self.write_disposition_record(bundle_path, result)\n            self.write_evidence_contribution(bundle_path, result)\n            self.cleanup_incoming(bundle_path)\n            return 0 if result == 'admitted' else 1\n        else:\n            # Existing logic for other input types\n            pass\n\n    def write_disposition_record(self, bundle_path, result):\n        record_path = f'receipts/current/{os.path.basename(bundle_path)}.json'\n        with open(record_path, 'w') as record_file:\n            record_file.write(f'{{\"bundle\": \"{bundle_path}\", \"result\": \"{result}\"}}')\n\n    def write_evidence_contribution(self, bundle_path, result):\n        evidence_path = f'tracking/evidence_plane/{os.path.basename(bundle_path)}.json'\n        with open(evidence_path, 'w') as evidence_file:\n            evidence_file.write(f'{{\"bundle\": \"{bundle_path}\", \"result\": \"{result}\"}}')\n\n    def cleanup_incoming(self, bundle_path):\n        os.remove(bundle_path)\n\nif __name__ == \"__main__\":\n    pipeline = MultimodalPipeline()\n    for bundle in os.listdir('incoming/'):\n        bundle_path = os.path.join('incoming/', bundle)\n        exit_code = pipeline.process_bundle(bundle_path)\n        print(f'Processed {bundle_path} with exit code {exit_code}')\n"
    }
  ]
}
```
