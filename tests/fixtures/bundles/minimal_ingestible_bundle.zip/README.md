# Minimal ingestible bundle fixture

For smoke tests only.
